<html>
    <head>
        <title>Sistema de Notícias</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="./_misc/estilo.css">
        <script src="./_misc/jsacme.js"></script>
    </head>
    
    <?php

    ?>

    
    <body>
        
        <header>
            <h1>Noticias sobre quadrinhos</h1>
        </header>
        
        <nav>
            <?php include_once './_misc/menu.php'; ?>
        </nav>
        
        <section>
           
            <?php
            
            ?>
            
        </section>

        <footer>
            HQ - As melhores noticias sobre quadrinhos
        </footer>
        
    </body>
</html>