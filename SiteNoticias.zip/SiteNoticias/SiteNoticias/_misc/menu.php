<?php

    echo '<br><a href="index.php">Home</a>';

    echo '<br><a href="#">Localizar noticia</a>';
    
    echo '<br><a href="#">Área ADM</a>';
?>